Fire-bullet-with-trail-effect
=============================

Fire bullet with trail effect is often require in gaming creating gun that shoots bullet followed by a trail. Trail effect can be implemented by using trail renderer component in unity. 
<p>You can find complete tutorial on how to use this code repo here : <a href="http://www.theappguruz.com/blog/fire-bullet-trail-effect" target="_blank">Fire Bullet With Trail Effect</a></p>

This Tutorial has been presented by The App Guruz - One of the best <a href="http://www.theappguruz.com/mobile-application-development/">Game Development Company in India</a>
