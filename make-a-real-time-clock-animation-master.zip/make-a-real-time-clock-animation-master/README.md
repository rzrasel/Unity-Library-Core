# make-a-real-time-clock-animation

Main objective of this post is to give you an idea about how to make realtime clock.

You can find complete tutorial on Real Time Clock Animation : [How To Make A Real Time Clock Animation](http://www.theappguruz.com/blog/how-to-make-a-real-time-clock-animation)

This Tutorial has been presented by The App Guruz - One of the best [3D Game Development Company in India](http://www.theappguruz.com/3d-game-development)
